# Karl Jones, Dec 2023

from typing import List

from customtkinter import CTkFrame

from .ctkformattedframe import CTkFormattedFrame


class CTkFrameLayout(CTkFormattedFrame):
    """CTkFrameLayout

    The frame layout class that will contain a number of frames in a predefined layout
    """

    @property
    def frameGrid(self) -> List[List[CTkFormattedFrame]] | None:
        """frameGrid

        The 'frameGrid' property exposes the predefined grid of frames
        It may be None:

        Returns:
            List[List[CTkFormattedFrame]] | None: the grid of frames
        """
        return self._frameGrid

    @property
    def frameStack(self) -> List[CTkFormattedFrame] | None:
        """frameStack

        The 'frameStack' property exposes the predefined stack of frames
        It may be None:

        Returns:
            List[List[CTkFormattedFrame]] | None: the stack of frames
        """
        return self._frameStack

    @property
    def top(self) -> CTkFormattedFrame | None:
        """top

        The 'top' property exposes the top frame
        It may be None:

        Returns:
            CTkFormattedFrame | None: the top frame
        """
        return self._top

    @property
    def bottom(self) -> CTkFormattedFrame | None:
        """bottom

        The 'bottom' property exposes the bottom frame
        It may be None:

        Returns:
            CTkFormattedFrame | None: the bottom frame
        """
        return self._bottom

    @property
    def left(self) -> CTkFormattedFrame | None:
        """left

        The 'left' property exposes the left frame
        It may be None:

        Returns:
            CTkFormattedFrame | None: the left frame
        """
        return self._left

    @property
    def right(self) -> CTkFormattedFrame | None:
        """right

        The 'right' property exposes the right frame
        It may be None:

        Returns:
            CTkFormattedFrame | None: the right frame
        """
        return self._right

    @property
    def main(self) -> CTkFormattedFrame | None:
        """main

        The 'main' property exposes the main frame
        It may be None:

        Returns:
            CTkFormattedFrame | None: the main frame
        """
        return self._main

    # @main.setter
    # def main(self, value) -> None:
    #     self._main

    def __init__(
        self,
        master: CTkFrame,
        *args,
        **kwargs,
    ) -> None:
        """__init__

        Initialises the frame layout

        Args:
            master (CTkFrame): master frame into which this frame layout is placed
        """

        #  Initialise the CTkFormattedFrame

        super().__init__(master, *args, **kwargs)

        #  Initialise the properties

        self._frameGrid: List[List[CTkFormattedFrame]] | None = None
        self._frameStack: List[CTkFormattedFrame] | None = None
        self._top: CTkFormattedFrame | None = None
        self._bottom: CTkFormattedFrame | None = None
        self._left: CTkFormattedFrame | None = None
        self._right: CTkFormattedFrame | None = None
        self._main: CTkFormattedFrame | None = None

        #  Set the frame layout's descriptors

        self._str = "CTkFrameLayout"
        self._repr = (
            "CTkFrameLayout (master={master}, *args={*args}, **kwargs={**kwargs})"
        )
