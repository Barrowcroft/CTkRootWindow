# Karl Jones, Dec 2023

from typing import Optional, Tuple, List

from customtkinter import CTkFrame

from .framelayouts import CTkFormattedFrame
from .framelayouts import CTkFrameLayout


class CTkFrameLayoutGrid(CTkFrameLayout):
    """CTkFrameLayoutGrid

    The frame set class that will contain a grid of frames
    """

    def __init__(
        self,
        master: CTkFrame,
        *args,
        rows: Optional[int] = 2,
        columns: Optional[int] = 3,
        gutter: Optional[int] = 5,
        **kwargs,
    ) -> None:
        """__init__

        Initialises the frame grid

        Args:
            master (CTkFrame): master frame into which this frame is placed
            rows (int, optional): number of rows in the grid. Defaults to 2
            columns (int, optional): number of rows in the grid. Defaults to 3
            gutter (int, optional): gutter between frames in the grid. Defaults to 5
        """
        #  Initilise the CTkFrameLayout

        super().__init__(master, *args, **kwargs)

        #  Initialise the frame grid

        self._frameGrid: List[List[CTkFormattedFrame]] | None = []

        #  Create the grid of frames

        for _row in range(0, rows):
            _y_padding: Tuple[int, int] = (0, gutter) if (_row < rows - 1) else (0, 0)

            self._frameGrid.append([])
            self.grid_rowconfigure(index=_row, weight=1)

            for _column in range(0, columns):
                _x_padding: Tuple[int, int] = (
                    (0, gutter) if (_column < columns - 1) else (0, 0)
                )

                self.grid_columnconfigure(index=_column, weight=1)
                self._frameGrid[_row].append(CTkFormattedFrame(self))

                self._frameGrid[_row][_column].grid(
                    row=_row,
                    column=_column,
                    padx=_x_padding,
                    pady=_y_padding,
                    sticky="nsew",
                )
